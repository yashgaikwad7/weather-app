# Weather-WebApp
Build Web based Delhi/In web application using Js


#first of all you guys need to download some dependencies 

1.requests module from https://npmjs.com/package/requests
or you just type npm -i requests

2.you need to start localhost server by just typing 127.0.0.1:8000 or localhost:8000 on your browser 

that's it ..... here you got api based wheather web app

